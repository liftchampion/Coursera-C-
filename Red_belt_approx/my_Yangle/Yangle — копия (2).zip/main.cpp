#include "profile.h"


TotalDuration updatedocumentbase("updatedocumentbase total");
TotalDuration addqueriesstream("addqueriesstream total");
TotalDuration add("add total");
TotalDuration lookup("lookup total");

TotalDuration sorting("sorting total");
TotalDuration hitcount("hitcount total");
TotalDuration createsearchresults("createsearchresults total");


TotalDuration getdocument("+getdocument total");
TotalDuration splitby("+splitby total");
TotalDuration strip("+strip total");
TotalDuration splitintowords("+splitintowords total");
TotalDuration searchserver("+searchserver total");
TotalDuration createoutput("+createoutput total");
TotalDuration join("+join total");


#include "search_server.h"
#include "parse.h"
#include "test_runner.h"


#include <algorithm>
#include <iterator>
#include <map>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <random>
#include <thread>
using namespace std;

void TestFunctionality(
        const vector<string>& docs,
        const vector<string>& queries,
        const vector<string>& expected
) {
    istringstream docs_input(Join('\n', docs));
    istringstream queries_input(Join('\n', queries));

    SearchServer srv;
    srv.UpdateDocumentBase(docs_input);
    ostringstream queries_output;
    srv.AddQueriesStream(queries_input, queries_output);

    const string result = queries_output.str();
    const auto lines = SplitBy(Strip(result), '\n');
    ASSERT_EQUAL(lines.size(), expected.size());
    for (size_t i = 0; i < lines.size(); ++i) {
        ASSERT_EQUAL(lines[i], expected[i]);
    }
}

void TestSerpFormat() {
    const vector<string> docs = {
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    const vector<string> queries = {"london", "the"};
    const vector<string> expected = {
            "london: {docid: 0, hitcount: 1}",
            Join(' ', vector{
                    "the:",
                    "{docid: 0, hitcount: 1}",
                    "{docid: 1, hitcount: 1}"
            })
    };

    TestFunctionality(docs, queries, expected);
}

void TestTop5() {
    const vector<string> docs = {
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth"
    };

    const vector<string> queries = {"milk", "water", "rock"};
    const vector<string> expected = {
            Join(' ', vector{
                    "milk:",
                    "{docid: 0, hitcount: 1}",
                    "{docid: 1, hitcount: 1}",
                    "{docid: 2, hitcount: 1}",
                    "{docid: 3, hitcount: 1}",
                    "{docid: 4, hitcount: 1}"
            }),
            Join(' ', vector{
                    "water:",
                    "{docid: 7, hitcount: 1}",
                    "{docid: 8, hitcount: 1}",
            }),
            "rock:",
    };
    TestFunctionality(docs, queries, expected);
}

void TestHitcount() {
    const vector<string> docs = {
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
    };
    const vector<string> queries = {"the", "wall", "all", "is", "the is"};
    const vector<string> expected = {
            Join(' ', vector{
                    "the:",
                    "{docid: 0, hitcount: 2}",
                    "{docid: 1, hitcount: 1}",
            }),
            "wall: {docid: 1, hitcount: 1}",
            "all:",
            Join(' ', vector{
                    "is:",
                    "{docid: 3, hitcount: 4}",
                    "{docid: 0, hitcount: 1}",
            }),
            Join(' ', vector{
                    "the is:",
                    "{docid: 3, hitcount: 4}",
                    "{docid: 0, hitcount: 3}",
                    "{docid: 1, hitcount: 1}",
            }),
    };
    TestFunctionality(docs, queries, expected);
}

void TestRanking() {
    const vector<string> docs = {
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
    };

    const vector<string> queries = {"moscow is the capital of russia"};
    const vector<string> expected = {
            Join(' ', vector{
                    "moscow is the capital of russia:",
                    "{docid: 7, hitcount: 6}",
                    "{docid: 14, hitcount: 6}",
                    "{docid: 0, hitcount: 4}",
                    "{docid: 1, hitcount: 4}",
                    "{docid: 2, hitcount: 4}",
            })
    };
    TestFunctionality(docs, queries, expected);
}

void TestBasicSearch() {
    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education"
    };

    const vector<string> queries = {
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about"
    };

    const vector<string> expected = {
            Join(' ', vector{
                    "we need some help:",
                    "{docid: 9, hitcount: 2}",
                    "{docid: 0, hitcount: 1}"
            }),
            Join(' ', vector{
                    "it:",
                    "{docid: 8, hitcount: 2}",
                    "{docid: 6, hitcount: 1}",
                    "{docid: 7, hitcount: 1}",
            }),
            "i love this game: {docid: 2, hitcount: 4}",
            "tell me why: {docid: 5, hitcount: 2}",
            "dislike:",
            "about: {docid: 3, hitcount: 2}",
    };
    TestFunctionality(docs, queries, expected);
}


void TestSpeedOneIteration() {

    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    //cout << docs.size() << endl;

    const vector<string> queries = {
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland"
    };
    //cout << queries.size() << endl;


    istringstream docs_input(Join('\n', docs));
    istringstream queries_input(Join('\n', queries));

    SearchServer srv;
    srv.UpdateDocumentBase(docs_input);
    ostringstream queries_output;
    srv.AddQueriesStream(queries_input, queries_output);

    const string result = queries_output.str();

}

void TestSpeed() {
    LOG_DURATION("test speed total");
    cerr << "running" << endl;
    for (int i = 0; i < 1000; i++) {
        TestSpeedOneIteration();
        if (i % 100 == 0) {
            cerr << i << endl;
        }
    }
}

void TestReadingNew() {
    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    istringstream docs_input(Join('\n', docs));

    vector<vector<string>> words(1, vector<string>(1));
    int current_doc = 0;
    int current_word = 0;
    words.reserve(200);
    words[0].reserve(1000);
    words[0][0].reserve(100);

    //string chars;
    bool was_space = false;
    //string word;
    //word.reserve(100);
    for (char c; c = docs_input.get();) {
        //cout << "<" << c << "> " << static_cast<int>(c) << endl;
        if (c == -1) {
            //if (!word.empty()) {
            //    words[current_doc].push_back(word);
            //    word.clear();
            //}
            break;
        }
        else if (c != ' ' && c != '\n') {
            words[current_doc][current_word].push_back(c);
            was_space = false;
        }
        else if (c == ' ' && !was_space) {
            was_space = true;
            current_word++;
            words[current_doc].push_back("");
            words[current_doc][current_word].reserve(100);
        }
        else if (c == ' ' && was_space) {}
        else if (c == '\n'){
            current_doc++;
            current_word = 0;
            words.push_back(vector<string>(1));
            words[current_doc].reserve(1000);
            words[current_doc].push_back("");
            words[current_doc][current_word].reserve(100);
        }
    }



    //string str(docs_input.str());
    //cout << endl << str << endl << endl;
    //cout << endl << words << endl << endl;
}

void TestReadingOld() {

    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    istringstream docs_input(Join('\n', docs));
    vector<vector<string>> documents(200);
    int curr_doc = 0;

    for (string current_document; getline(docs_input, current_document); ) {
        istringstream words_input(current_document);
        documents[curr_doc] = {istream_iterator<string>(words_input), istream_iterator<string>()};
        curr_doc++;
    }
    //cout << documents << endl;


}

int main() {
    TestRunner tr;
    RUN_TEST(tr, TestSerpFormat);
    RUN_TEST(tr, TestTop5);
    RUN_TEST(tr, TestHitcount);
    RUN_TEST(tr, TestRanking);
    RUN_TEST(tr, TestBasicSearch);
    //TestSpeed();


    //TestReadingNew();
    /*{
        LOG_DURATION("Old-style");
        for (int i = 0; i < 1000; i++) {
            TestReadingOld();
        }
    }

    {
        LOG_DURATION("New-style");
        for (int i = 0; i < 1000; i++) {
            TestReadingNew();
        }
    }*/


    //TestReadingNew();
    //TestReadingOld();
}
