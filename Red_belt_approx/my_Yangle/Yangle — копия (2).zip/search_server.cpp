#include "profile.h"

extern TotalDuration splitintowords;
extern TotalDuration searchserver;
extern TotalDuration updatedocumentbase;
extern TotalDuration addqueriesstream;
extern TotalDuration add;
extern TotalDuration lookup;
extern TotalDuration sorting;
extern TotalDuration hitcount;
extern TotalDuration createsearchresults;
extern TotalDuration createoutput;


#include "search_server.h"
#include "iterator_range.h"


#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>

vector<string> SplitIntoWords(const string& line) {
    //ADD_DURATION(splitintowords);
    istringstream words_input(line);
    return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream& document_input) {
    //ADD_DURATION(searchserver);
    UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
    //ADD_DURATION(updatedocumentbase);
    InvertedIndex new_index;

    for (string current_document; getline(document_input, current_document); ) {
        new_index.Add(move(current_document));
    }

    index = move(new_index);
}

void SearchServer::AddQueriesStream(
        istream& query_input, ostream& search_results_output
) {
    //ADD_DURATION(addqueriesstream);
    vector<size_t> docid_count(index.GetDocsCount(), 0);
    for (string current_query; getline(query_input, current_query); ) {
        const auto words = SplitIntoWords(current_query);


        {
            //ADD_DURATION(hitcount);
            for (const auto &word : words) {
                for (const auto [id, count] : index.GetHitcounts(word)) {
                    docid_count[id] += count;
                }
            }
        }

        vector<pair<size_t, size_t>> search_results;
        {
            //ADD_DURATION(createsearchresults);
            search_results.reserve(docid_count.size());
            for (size_t i = 0; i < docid_count.size(); i++) {
                if (docid_count[i] != 0) {
                    search_results.push_back(make_pair(i, docid_count[i]));
                }
            }
        }
        fill(docid_count.begin(), docid_count.end(), 0);


        {
            //ADD_DURATION(sorting);
            size_t head_size = search_results.size() > 5 ? 5 : search_results.size();
            partial_sort(
                    begin(search_results),
                    begin(search_results) + head_size,
                    end(search_results),
                    [](pair<size_t, size_t> lhs, pair<size_t, size_t> rhs) {
                        int64_t lhs_docid = lhs.first;
                        auto lhs_hit_count = lhs.second;
                        int64_t rhs_docid = rhs.first;
                        auto rhs_hit_count = rhs.second;
                        return make_pair(lhs_hit_count, -lhs_docid) > make_pair(rhs_hit_count, -rhs_docid);
                    }
            );
        }

        {
            //ADD_DURATION(createoutput);
            search_results_output << current_query << ':';
            for (auto[docid, hitcount] : Head(search_results, 5)) {
                search_results_output << " {"
                                      << "docid: " << docid << ", "
                                      << "hitcount: " << hitcount << '}';
            }
            search_results_output << endl;
        }
    }
}

map<string, map<size_t, size_t>>& InvertedIndex::GetSubmap(const char first_char) {
    /*if (first_char <= 'n') {
        if (first_char <= 'g') {
            return index[0];
        }
        else {
            return index[1];
        }
    }
    else {
        if (first_char <= 't') {
            return index[2];
        }
        else {
            return index[3];
        }
    }*/
    return index[static_cast<int>(first_char - 'a')];
};

void InvertedIndex::AddWord(const string& word, const size_t docid) {
    GetSubmap(word[0])[word][docid]++;
}

void InvertedIndex::Add(const string& document) {
    //ADD_DURATION(add);
    //docs.push_back(document);

    //const size_t docid = docs.size() - 1;

    const size_t docid = docs_count;
    for (const auto& word : SplitIntoWords(document)) {
        AddWord(word, docid);
    }


    //for (const auto& word : SplitIntoWords(document)) {
    //    index[word].push_back(docid);
    //}

    docs_count++;
}

map<size_t, size_t>& InvertedIndex::GetHitcounts(const string& word) {
    map<string, map<size_t, size_t>>& submap = GetSubmap(word[0]);
    return submap[word];
}

list<size_t> InvertedIndex::Lookup(const string& word) const {
    //ADD_DURATION(lookup);
    /*if (auto it = index.find(word); it != index.end()) {
        return it->second;
    } else {
        return {};
    }*/
    return {};
}
