#pragma once

#include "profile.h"

extern TotalDuration getdocument;

#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
using namespace std;

class InvertedIndex {
public:
    InvertedIndex()
            : docs_count(0)
            , index(vector<map<string, map<size_t, size_t>>>(26)){}

    void Add(const string& document);
    map<size_t, size_t>& GetHitcounts(const string& word);
    list<size_t> Lookup(const string& word) const;

    //const string& GetDocument(size_t id) const {
    //    ADD_DURATION(getdocument);
    //    return docs[id];
    //}
    size_t GetDocsCount() const {
        return docs_count;
    }

private:
    //map<string, list<size_t>> index;
    vector<map<string, map<size_t, size_t>>> index;
    //vector<string> docs;
    size_t docs_count;

    void AddWord(const string& word, const size_t docid);
    map<string, map<size_t, size_t>>& GetSubmap(const char first_char);
};

class SearchServer {
public:
    SearchServer() = default;
    explicit SearchServer(istream& document_input);
    void UpdateDocumentBase(istream& document_input);
    void AddQueriesStream(istream& query_input, ostream& search_results_output);

private:
    InvertedIndex index;
};
