#pragma once

#include "profile.h"
#include "search_server.h"

#include <future>
#include <mutex>

extern TotalDuration getdocument;

using namespace std;


class InvertedIndexM {
public:

    size_t GetDocsCount();

    const unordered_map<uint16_t, uint16_t>& GetHitcount(const string& word);

    void ReplaceDocumentsOT(istream& document_input);

    void ReplaceDocuments(istream& document_input);

    void AddDocuments(istream& document_input);

    void MakeMaps();

    mutex& GetMutex();

private:
    unordered_map<string, pair<vector<uint16_t>, unordered_map<uint16_t, uint16_t>>> index_;
    uint16_t docs_count = 0u;
    const unordered_map<uint16_t, uint16_t> _empty = {};
    mutex guard;
    vector<future<void>> updates;
};

class SearchServerM {
public:
    SearchServerM() = default;
    explicit SearchServerM(istream& document_input);
    void UpdateDocumentBase(istream& document_input);
    void AppendDocumentBase(istream& document_input);
    void AddQueriesStreamOT(istream& query_input, ostream& search_results_output);
    void AddQueriesStream(istream& query_input, ostream& search_results_output);

private:
    vector<future<void>> requests;
    InvertedIndexM index;
    void CreateOutput(vector<pair<uint16_t, uint16_t>>& relevancy, ostream& search_results_output) const;

};
