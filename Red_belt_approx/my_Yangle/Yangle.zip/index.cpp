#include "index.h"

bool operator < (const WordIt& lhs, const WordIt& rhs){
    return lhs.MakeString() < rhs.MakeString();
}

ostream& operator << (ostream& str, const WordIt& w) {
    return cout << w.MakeString();
}
