#pragma once

#include <iostream>
#include <map>
#include <string>
#include <iterator>
#include "test_runner.h"

using namespace std;

class WordIt {
public:
    WordIt(istream_iterator<char> begin_, size_t len_)
            : begin(begin_)
            , len(len_) {}
    string MakeString() const{
        string str;
        size_t count = 0;
        for (istream_iterator<char> it = begin;; it++) {
            str.push_back(*it);
            if (++count == len) {
                break;
            }
        }
        return str;
    }
private:
    istream_iterator<char> begin;
    size_t len;
};

bool operator < (const WordIt& lhs, const WordIt& rhs);

ostream& operator << (ostream& str, const WordIt& w);

class Index {
public:
    void Print() const {
        cout << index;
    }
    void Update(istream& input) {
        index.clear();
        noskipws(input);

        size_t word_size = 0;
        istream_iterator<char> word_begin(input);

        bool was_space = true;

        size_t docid = 0;

        for (istream_iterator<char> it(input); it != istream_iterator<char>(); it = next(it)){
            char current = *it;
            cout << "<" << current << "> ";
            if (current != ' ' && current != '\n') {
                if (was_space) {
                    word_begin = it;
                    word_size = 1;
                    was_space = false;
                }
                else {
                    word_size++;
                }
            }
            else if (current == ' ' && current != '\n'){
                if (word_size != 0) {
                    index[WordIt(word_begin, word_size)][docid]++;
                    word_size = 0;
                }
            }
            else if (current == '\n') {
                if (word_size != 0) {
                    index[WordIt(word_begin, word_size)][docid]++;
                    word_size = 0;
                }
                docid++;
            }
        }
        if (word_size != 0) {
            index[WordIt(word_begin, word_size)][docid]++;
        }
        skipws(input);
    }
private:
    map<WordIt, map<size_t, size_t>> index;
};
