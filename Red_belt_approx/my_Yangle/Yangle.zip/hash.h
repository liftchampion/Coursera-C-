#pragma once

#include <string>
#include <cstdint>
#include <vector>
#include "test_runner.h"
#include <cmath>
#include <iomanip>

using namespace std;

vector<uint_fast64_t> HashWord(const string& word);