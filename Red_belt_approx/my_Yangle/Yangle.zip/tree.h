#pragma once

#include "test_runner.h"

#include <string>
#include <map>
#include <iostream>
#include <cstdint>
#include <string_view>

using namespace std;

class TreeNode {
public:
    TreeNode();
    void AddWord(string_view word, size_t docid, uint8_t new_deep);
    const map<size_t, size_t>& GetHitcount(queue<char>& word) const;
    void Print() const;
private:
    char value;
    uint8_t deep;
    map<size_t, size_t> docs_to_count;
    map<size_t, size_t> empty;
    map<char, TreeNode> children;
};

class Forest {
public:
    void AddWord(string_view word, size_t docid);
    const map<size_t, size_t>& GetHitcount(queue<char>& word) const;
    void Print() const;
private:
    map<char, TreeNode> trees;
    map<size_t, size_t> empty;
};
