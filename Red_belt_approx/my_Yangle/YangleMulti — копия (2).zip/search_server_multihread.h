#pragma once

#include "profile.h"
#include "search_server.h"
#include "sync.h"

extern TotalDuration getdocument;

#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
#include <unordered_map>
#include <cstdint>
#include <future>
using namespace std;

class InvertedIndexM {
public:

    size_t GetDocsCount() const {
        return docs_count;
    }

    const unordered_map<uint16_t, uint16_t>& GetHitcount(const string& word);

    void ReplaceDocuments(istream& document_input);

    void AddDocuments(istream& document_input);

    void MakeMaps();

private:
    SyncIndex index_;
    uint16_t docs_count = 0u;
    const unordered_map<uint16_t, uint16_t> _empty = {};
};

class SearchServerM {
public:
    SearchServerM() = default;
    explicit SearchServerM(istream& document_input);
    void UpdateDocumentBaseOT(istream& document_input);
    void AppendDocumentBaseOT(istream& document_input);
    void AddQueriesStreamOT(istream& query_input, ostream& search_results_output);
    void UpdateDocumentBase(istream& document_input);
    void AppendDocumentBase(istream& document_input);
    void AddQueriesStream(istream& query_input, ostream& search_results_output);

private:
    InvertedIndexM index;
    void CreateOutput(vector<pair<uint16_t, uint16_t>>& relevancy, ostream& search_results_output) const;
    vector<future<void>> queries;
    vector<future<void>> updates;
};

