#include "search_server_multihread.h"
#include "profile.h"
#include "test_runner.h"


//extern TotalDuration updatedocumentbase;
//extern TotalDuration addqueriesstream;
//extern TotalDuration add;

//extern TotalDuration sorting;
//extern TotalDuration hitcount;

//extern TotalDuration createoutput;
//extern TotalDuration refillvector;


#include "iterator_range.h"


#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <queue>
#include <utility>


void InvertedIndexM::ReplaceDocuments(istream& document_input){
    docs_count = 0u;
    SyncIndex new_index;
    for (string current_document; getline(document_input, current_document);) {
        char sep = ' ';
        size_t b = 0;
        while ((b = current_document.find_first_not_of(sep, b)) != current_document.npos) {
            size_t e = current_document.find_first_of(sep, b);
            new_index[current_document.substr(b, e-b)].ref_to_value.first.push_back(docs_count);
            b = e;
        }
        docs_count++;
    }
    /*for (auto& [key, value] : new_index.BuildOrdinaryMap()) {
        for (const auto n : value.first) {
            value.second[n]++;
        }
    }*/
    new_index.FillHitcount();
    index_ = move(new_index);
    //cout << index_.BuildOrdinaryMap() << endl;
}

void InvertedIndexM::AddDocuments(istream& document_input){
    for (string current_document; getline(document_input, current_document);) {
        char sep = ' ';
        size_t b = 0;
        while ((b = current_document.find_first_not_of(sep, b)) != current_document.npos) {
            size_t e = current_document.find_first_of(sep, b);
            index_[current_document.substr(b, e-b)].ref_to_value.first.push_back(docs_count);
            b = e;
        }
        docs_count++;
    }
}

void InvertedIndexM::MakeMaps(){
    for (auto& [key, value] : index_.BuildOrdinaryMap()) {
        for (const auto n : value.first) {
            value.second[n]++;
        }
    }
}

const unordered_map<uint16_t, uint16_t>& InvertedIndexM::GetHitcount(const string& word){
    if (!index_.Find(word)){
        return _empty;
    }
    else {
        return index_[word].ref_to_value.second;
    }
};

SearchServerM::SearchServerM(istream& document_input) {
    //ADD_DURATION(searchserver);
    UpdateDocumentBaseOT(document_input);
}

void SearchServerM::UpdateDocumentBaseOT(istream& document_input) {
    //ADD_DURATION(updatedocumentbase);
    index.ReplaceDocuments(document_input);
}

void SearchServerM::UpdateDocumentBase(istream& document_input) {
    updates.push_back(async(launch::async, &SearchServerM::UpdateDocumentBaseOT, this, ref(document_input)));
    //UpdateDocumentBaseOT(document_input);
}

void SearchServerM::AppendDocumentBaseOT(istream& document_input) {
    //ADD_DURATION(updatedocumentbase);
    index.AddDocuments(document_input);
    index.MakeMaps();
}

void SearchServerM::AppendDocumentBase(istream& document_input) {
    updates.push_back(async(launch::async, &SearchServerM::AppendDocumentBaseOT, this, ref(document_input)));
    //AppendDocumentBaseOT(document_input);
}

void SearchServerM::CreateOutput(vector<pair<uint16_t, uint16_t>>& relevancy, ostream& search_results_output) const{
    //cout << relevancy << endl;
    {
        //ADD_DURATION(sorting);
        uint16_t head_size = relevancy.size() > 5u ? 5u : relevancy.size();
        partial_sort(relevancy.begin(), relevancy.begin() + head_size, relevancy.end(), CompFunc);
    }
    //cout << relevancy << endl << endl;
    {
        //ADD_DURATION(createoutput);
        search_results_output << ":";
        bool is_first = true;
        for (uint16_t i = 0; i < (relevancy.size() >= 5u ? 5u : relevancy.size()); i++) {
            if (relevancy[i].first != 0) {
                search_results_output << " {docid: " << relevancy[i].second
                                      << ", hitcount: " << relevancy[i].first << "}";

            }
        }
        search_results_output << '\n';
    }
    {
        //ADD_DURATION(refillvector);
        fill(relevancy.begin(), relevancy.end(), pair<uint16_t, uint16_t>(0u, 0u));
    }
}

void SearchServerM::AddQueriesStreamOT(
        istream& query_input, ostream& search_results_output
) {
    //ADD_DURATION(addqueriesstream);
    vector<pair<uint16_t, uint16_t>> relevancy(index.GetDocsCount());
    for (string current_query; getline(query_input, current_query);) {
        search_results_output << current_query;
        char sep = ' ';
        size_t b = 0;
        while ((b = current_query.find_first_not_of(sep, b)) != current_query.npos) {
            size_t e = current_query.find_first_of(sep, b);
            relevancy += index.GetHitcount(current_query.substr(b, e-b));
            b = e;
        }
        CreateOutput(relevancy, search_results_output);
    }

}

void SearchServerM::AddQueriesStream(
        istream& query_input, ostream& search_results_output
) {
    //updates[updates.size() - 1].get();
    queries.push_back(async(launch::async, &SearchServerM::AddQueriesStreamOT, this, ref(query_input), ref(search_results_output)));
    //AddQueriesStreamOT(query_input, search_results_output);
}


