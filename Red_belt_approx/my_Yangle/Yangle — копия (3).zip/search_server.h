#pragma once

#include "profile.h"
#include "tree.h"

extern TotalDuration getdocument;

#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
using namespace std;

class InvertedIndex {
public:
    InvertedIndex()
            : docs_count(0) {}


    size_t GetDocsCount() const {
        return docs_count;
    }


    Forest index_forest;
    size_t docs_count;
private:
    //map<string, list<size_t>> index;
    //vector<map<string, map<size_t, size_t>>> index;

    //vector<string> docs;


    void AddWord(const string& word, const size_t docid);
    map<string, map<size_t, size_t>>& GetSubmap(const char first_char);
};

class SearchServer {
public:
    SearchServer() = default;
    explicit SearchServer(istream& document_input);
    void UpdateDocumentBase(istream& document_input);
    void AddQueriesStream(istream& query_input, ostream& search_results_output);

private:
    InvertedIndex index;
    void CreateOutput(vector<pair<size_t, size_t>>& relevancy, ostream& search_results_output) const;
};
