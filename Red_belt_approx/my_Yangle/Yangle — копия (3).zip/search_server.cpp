#include "profile.h"


//extern TotalDuration updatedocumentbase;
//extern TotalDuration addqueriesstream;
//extern TotalDuration add;

//extern TotalDuration sorting;
//extern TotalDuration hitcount;

//extern TotalDuration createoutput;
//extern TotalDuration refillvector;


#include "search_server.h"
#include "iterator_range.h"


#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <queue>
#include <utility>



SearchServer::SearchServer(istream& document_input) {
    //ADD_DURATION(searchserver);
    UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
    //ADD_DURATION(updatedocumentbase);
    InvertedIndex new_index;

    queue<char> word;
    size_t current_doc = 0;
    for (char c; c = document_input.get();) {
        if (c == -1) {
            new_index.index_forest.AddWord(word, current_doc);
            break;
        }
        if (c != ' ' && c != '\n'){
            word.push(c);
        }
        else if (c == ' '){
            new_index.index_forest.AddWord(word, current_doc);
        }
        else if (c == '\n') {
            new_index.index_forest.AddWord(word, current_doc);
            current_doc++;
        }
    }
    index = move(new_index);
    index.docs_count = current_doc + 1;
}

void operator += (vector<pair<size_t, size_t>>& lhs, const map<size_t, size_t>& rhs){
    for (const auto& [key, value] : rhs) {
        lhs[key].first += value;
        lhs[key].second = key;
    }
    //cout << lhs << endl;
    //cout << rhs << endl << endl;
}

bool CompFunc(const pair<size_t, size_t>& lhs, const pair<size_t, size_t>& rhs) {
    if (lhs.first != rhs.first) {
        return lhs.first > rhs.first;
    }
    else {
        return lhs.second < rhs.second;
    }
}

void SearchServer::CreateOutput(vector<pair<size_t, size_t>>& relevancy, ostream& search_results_output) const{
    //cout << relevancy << endl;
    {
        //ADD_DURATION(sorting);
        size_t head_size = relevancy.size() > 5u ? 5u : relevancy.size();
        partial_sort(relevancy.begin(), relevancy.begin() + head_size, relevancy.end(), CompFunc);
    }
    //cout << relevancy << endl << endl;
    {
        //ADD_DURATION(createoutput);
        search_results_output << ":";
        bool is_first = true;
        for (size_t i = 0; i < (relevancy.size() >= 5u ? 5u : relevancy.size()); i++) {
            if (relevancy[i].first != 0) {
                search_results_output << " {docid: " << relevancy[i].second
                                      << ", hitcount: " << relevancy[i].first << "}";

            }
        }
        search_results_output << '\n';
    }
    {
        //ADD_DURATION(refillvector);
        fill(relevancy.begin(), relevancy.end(), pair<size_t, size_t>(0, 0));
    }
}

void SearchServer::AddQueriesStream(
        istream& query_input, ostream& search_results_output
) {
    //ADD_DURATION(addqueriesstream);
    vector<pair<size_t, size_t>> relevancy(index.docs_count);
    //fill(relevancy.begin(), relevancy.end(), pair<size_t, size_t>(0, 0));
    queue<char> word;
    for (char c; c = query_input.get();) {
        if (c == -1) {
            relevancy += index.index_forest.GetHitcount(word);
            CreateOutput(relevancy, search_results_output);
            break;
        }
        if (c != ' ' && c != '\n'){
            word.push(c);
            search_results_output << c;
        }
        else if (c == ' '){
            relevancy += index.index_forest.GetHitcount(word);
            search_results_output << c;
        }
        else if (c == '\n') {
            relevancy += index.index_forest.GetHitcount(word);
            CreateOutput(relevancy, search_results_output);
        }
    }
}

