#include "tree.h"
#include "profile.h"

//extern TotalDuration hitcount;
//extern TotalDuration add;

TreeNode::TreeNode(){
    value = '#';
}

void TreeNode::AddWord(queue<char>& word, size_t docid){
    value = word.front();
    word.pop();
    if (word.empty()) {
        docs_to_count[docid]++;
    }
    else {
        children[word.front()].AddWord(word, docid);
    }
}

const map<size_t, size_t>& TreeNode::GetHitcount(queue<char>& word) const {
    word.pop();
    if (word.empty()) {
        return docs_to_count;
    }
    else if (children.count(word.front()) == 0) {
        while (!word.empty()) {
            word.pop();
        }
        return empty;
    }
    else {
        return children.at(word.front()).GetHitcount(word);
    }

}

void TreeNode::Print() const {
    cout << "[ " << value << " ";
    cout << docs_to_count << " ";
    for (const auto& [key, value] : children) {
        cout << "{ " <<key << " ";
        value.Print();
        cout << " } ";
    }
    cout << " ] ";
}

void Forest::AddWord(queue<char>& word, size_t docid) {
    //ADD_DURATION(add);
    if (word.empty()) {
        return;
    }
    trees[word.front()].AddWord(word, docid);
}

const map<size_t, size_t>& Forest::GetHitcount(queue<char>& word) const {
    //ADD_DURATION(hitcount);
    if (word.empty()) {
        return empty;
    }
    if (trees.count(word.front()) == 0) {
        while (!word.empty()) {
            word.pop();
        }
        return empty;
    }
    else {
        return trees.at(word.front()).GetHitcount(word);
    }
}

void Forest::Print() const{
    for (const auto& [key, value] : trees) {
        cout << "{ " <<key << " ";
        value.Print();
        cout << " } ";
    }
}