#pragma once

#include "profile.h"
#include "tree.h"

extern TotalDuration getdocument;

#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
#include <unordered_map>
#include <cstdint>
using namespace std;

void operator += (vector<pair<uint16_t, uint16_t>>& lhs, const unordered_map<uint16_t, uint16_t>& rhs);
void operator += (vector<pair<size_t, size_t>>& lhs, const map<size_t, size_t>& rhs);

class InvertedIndex {
public:



    size_t GetDocsCount() const {
        return docs_count;
    }

    const unordered_map<uint16_t, uint16_t>& GetHitcount(const string& word) const;

    void AddDocuments(istream& document_input);

private:
    unordered_map<string, pair<vector<uint16_t>, unordered_map<uint16_t, uint16_t>>> index_;
    uint16_t docs_count = 0u;
    const unordered_map<uint16_t, uint16_t> _empty = {};
};

class SearchServer {
public:
    SearchServer() = default;
    explicit SearchServer(istream& document_input);
    void UpdateDocumentBase(istream& document_input);
    void AddQueriesStream(istream& query_input, ostream& search_results_output);

private:
    InvertedIndex index;
    void CreateOutput(vector<pair<uint16_t, uint16_t>>& relevancy, ostream& search_results_output) const;
};
