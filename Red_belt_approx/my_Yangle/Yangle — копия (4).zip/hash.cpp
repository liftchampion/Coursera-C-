#include "hash.h"

using namespace std;

vector<uint_fast64_t > HashWord(const string& word){
    vector<uint_fast64_t > hash_v(12, uint_fast64_t (1e18));
    //cout << hash_v << endl;
    int free_space = 0;
    for (size_t i = 0; i < word.size(); i++) {
        //cout << setfill('0') << setw(19);
        //cout << (word[i] - 'a' + 10) * static_cast<uint64_t>(pow(10, 16 - i % 9 - free_space % 9)) << endl;
        hash_v[i / 9u] += (word[i] - 'a' + 10) * static_cast<uint_fast64_t >(pow(10, 16 - i % 9 - free_space % 9));
        free_space++;
    }
    return hash_v;
}

