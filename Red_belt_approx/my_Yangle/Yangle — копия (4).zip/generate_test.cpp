#include "generate_test.h"

using namespace std;

int MAX_WORDS = 10000;
int WORD_LENGHT = 100;
int DOCS_COUNT = 1000;
int DOC_SIZE = 1000;

vector<string> GenerateWords(){
    vector<string> result;
    result.reserve(MAX_WORDS);
    for (int i = 0; i < MAX_WORDS; i++) {
        string word;
        for (int j = 0; j < WORD_LENGHT; j++) {
            word.push_back('a' + rand() % ('z' + 1 - 'a'));
        }
        result.push_back(move(word));
    }
    //cout << result << endl;
    return result;
}

string GenerateDoc(const vector<string>& words) {
    string doc;
    doc.reserve(DOC_SIZE * (WORD_LENGHT + 1));
    for (int i = 0; i < DOC_SIZE; i++) {
        doc += words[rand() % MAX_WORDS];
        doc.push_back(' ');
    }
    //cout << doc << endl;
    return doc;
}

vector<string> GenerateDocs(const vector<string>& words) {
    //vector<string> words = GenerateWords();
    vector<string> docs;
    docs.reserve(DOCS_COUNT);
    srand(time(NULL));

    for (int i = 0; i < DOCS_COUNT; i++){
        if (i % 1000 == 0) {
            cout << i << endl;
        }
        docs.push_back(GenerateDoc(words));
    }

    /*ofstream fout;
    fout.open("docs.txt");
    for (int i = 0; i < DOCS_COUNT; i++){
        if (i % 1000 == 0) {
            cout << i << endl;
        }
        fout << GenerateDoc(words) << '\n';
    }
    fout.close();*/

    /*for (const auto& x : docs) {
        cout << x << endl;
    }*/
    return docs;
}

istringstream MakeStream(const vector<string>& items) {
    istringstream ss(Join('\n', items));
    return ss;
}
