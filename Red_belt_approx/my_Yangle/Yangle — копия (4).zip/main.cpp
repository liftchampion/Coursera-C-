#include "profile.h"
#include "tree.h"
#include "generate_test.h"
#include "index.h"
#include "hash.h"
#include <queue>
#include <sstream>
#include <cstdint>
#include <fstream>
#include <string_view>
#include <algorithm>
#include <cmath>
#include <unordered_map>
#include <utility>

/*
TotalDuration updatedocumentbase("updatedocumentbase total");
TotalDuration addqueriesstream("addqueriesstream total");
TotalDuration add("add total");

TotalDuration sorting("sorting total");
TotalDuration hitcount("hitcount total");

TotalDuration createoutput("createoutput total");
TotalDuration refillvector("refill total");*/


#include "search_server.h"
#include "parse.h"
#include "test_runner.h"


#include <algorithm>
#include <iterator>
#include <map>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <random>
#include <thread>
using namespace std;

void TestFunctionality(
        const vector<string>& docs,
        const vector<string>& queries,
        const vector<string>& expected
) {
    istringstream docs_input(Join('\n', docs));
    istringstream queries_input(Join('\n', queries));

    SearchServer srv;
    srv.UpdateDocumentBase(docs_input);
    ostringstream queries_output;
    srv.AddQueriesStream(queries_input, queries_output);

    const string result = queries_output.str();
    const auto lines = SplitBy(Strip(result), '\n');
    ASSERT_EQUAL(lines.size(), expected.size());
    for (size_t i = 0; i < lines.size(); ++i) {
        ASSERT_EQUAL(lines[i], expected[i]);
    }
}

void TestSerpFormat() {
    const vector<string> docs = {
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    const vector<string> queries = {"london", "the"};
    const vector<string> expected = {
            "london: {docid: 0, hitcount: 1}",
            Join(' ', vector{
                    "the:",
                    "{docid: 0, hitcount: 1}",
                    "{docid: 1, hitcount: 1}"
            })
    };

    TestFunctionality(docs, queries, expected);
}

void TestTop5() {
    const vector<string> docs = {
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth"
    };

    const vector<string> queries = {"milk", "water", "rock"};
    const vector<string> expected = {
            Join(' ', vector{
                    "milk:",
                    "{docid: 0, hitcount: 1}",
                    "{docid: 1, hitcount: 1}",
                    "{docid: 2, hitcount: 1}",
                    "{docid: 3, hitcount: 1}",
                    "{docid: 4, hitcount: 1}"
            }),
            Join(' ', vector{
                    "water:",
                    "{docid: 7, hitcount: 1}",
                    "{docid: 8, hitcount: 1}",
            }),
            "rock:",
    };
    TestFunctionality(docs, queries, expected);
}

void TestHitcount() {
    const vector<string> docs = {
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
    };
    const vector<string> queries = {"the", "wall", "all", "is", "the is"};
    const vector<string> expected = {
            Join(' ', vector{
                    "the:",
                    "{docid: 0, hitcount: 2}",
                    "{docid: 1, hitcount: 1}",
            }),
            "wall: {docid: 1, hitcount: 1}",
            "all:",
            Join(' ', vector{
                    "is:",
                    "{docid: 3, hitcount: 4}",
                    "{docid: 0, hitcount: 1}",
            }),
            Join(' ', vector{
                    "the is:",
                    "{docid: 3, hitcount: 4}",
                    "{docid: 0, hitcount: 3}",
                    "{docid: 1, hitcount: 1}",
            }),
    };
    TestFunctionality(docs, queries, expected);
}

void TestRanking() {
    const vector<string> docs = {
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
    };

    const vector<string> queries = {"moscow is the capital of russia"};
    const vector<string> expected = {
            Join(' ', vector{
                    "moscow is the capital of russia:",
                    "{docid: 7, hitcount: 6}",
                    "{docid: 14, hitcount: 6}",
                    "{docid: 0, hitcount: 4}",
                    "{docid: 1, hitcount: 4}",
                    "{docid: 2, hitcount: 4}",
            })
    };
    TestFunctionality(docs, queries, expected);
}

void TestBasicSearch() {
    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education"
    };

    const vector<string> queries = {
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about"
    };

    const vector<string> expected = {
            Join(' ', vector{
                    "we need some help:",
                    "{docid: 9, hitcount: 2}",
                    "{docid: 0, hitcount: 1}"
            }),
            Join(' ', vector{
                    "it:",
                    "{docid: 8, hitcount: 2}",
                    "{docid: 6, hitcount: 1}",
                    "{docid: 7, hitcount: 1}",
            }),
            "i love this game: {docid: 2, hitcount: 4}",
            "tell me why: {docid: 5, hitcount: 2}",
            "dislike:",
            "about: {docid: 3, hitcount: 2}",
    };
    TestFunctionality(docs, queries, expected);
}


void TestSpeedOneIteration() {

    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    //cout << docs.size() << endl;

    const vector<string> queries = {
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "we need some help",
            "it",
            "i love this game",
            "tell me why",
            "dislike",
            "about",
            "moscow is the capital of russia",
            "the",
            "wall",
            "all",
            "is",
            "the is",
            "milk",
            "water",
            "rock",
            "london",
            "the",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland"
    };
    //cout << queries.size() << endl;


    istringstream docs_input(Join('\n', docs));
    istringstream queries_input(Join('\n', queries));

    SearchServer srv;
    srv.UpdateDocumentBase(docs_input);
    ostringstream queries_output;
    srv.AddQueriesStream(queries_input, queries_output);

    const string result = queries_output.str();

}

void TestSpeed() {
    LOG_DURATION("test speed total");
    cerr << "running" << endl;
    for (int i = 0; i < 1000; i++) {
        TestSpeedOneIteration();
        if (i % 100 == 0) {
            cerr << i << endl;
        }
    }
}

void TestReadingNew() {
    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    istringstream docs_input(Join('\n', docs));

    vector<vector<string>> words(1, vector<string>(1));
    int current_doc = 0;
    int current_word = 0;
    words.reserve(200);
    words[0].reserve(1000);
    words[0][0].reserve(100);

    //string chars;
    bool was_space = false;
    //string word;
    //word.reserve(100);
    for (char c; c = docs_input.get();) {
        //cout << "<" << c << "> " << static_cast<int>(c) << endl;
        if (c == -1) {
            //if (!word.empty()) {
            //    words[current_doc].push_back(word);
            //    word.clear();
            //}
            break;
        }
        else if (c != ' ' && c != '\n') {
            words[current_doc][current_word].push_back(c);
            was_space = false;
        }
        else if (c == ' ' && !was_space) {
            was_space = true;
            current_word++;
            words[current_doc].push_back("");
            words[current_doc][current_word].reserve(100);
        }
        else if (c == ' ' && was_space) {}
        else if (c == '\n'){
            current_doc++;
            current_word = 0;
            words.push_back(vector<string>(1));
            words[current_doc].reserve(1000);
            words[current_doc].push_back("");
            words[current_doc][current_word].reserve(100);
        }
    }



    //string str(docs_input.str());
    //cout << endl << str << endl << endl;
    //cout << endl << words << endl << endl;
}

void TestReadingOld() {

    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    istringstream docs_input(Join('\n', docs));
    vector<vector<string>> documents(200);
    int curr_doc = 0;

    for (string current_document; getline(docs_input, current_document); ) {
        istringstream words_input(current_document);
        documents[curr_doc] = {istream_iterator<string>(words_input), istream_iterator<string>()};
        curr_doc++;
    }
    //cout << documents << endl;


}

/*
void MeasureTreeTime() {

    Forest forest;
    LOG_DURATION("tree 1000");
    for (int i = 0; i < 250; i++) {
        forest.AddWord("appkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkle", 1);
        forest.AddWord("applepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie", 1);
        forest.AddWord("aptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen", 3);
        forest.AddWord("alujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka", 2);
        forest.AddWord("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo", 1);
        forest.AddWord("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf", 1);
        forest.AddWord("yrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr", 1);
        forest.AddWord("kutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg", 1);
        forest.AddWord("fffffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff", 1);
        forest.AddWord("wqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", 1);
        forest.AddWord("iappkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkle", 1);
        forest.AddWord("iapplepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie", 1);
        forest.AddWord("iaptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen", 3);
        forest.AddWord("ialujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka", 2);
        forest.AddWord("iaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo", 1);
        forest.AddWord("iaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf", 1);
        forest.AddWord("iyrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr", 1);
        forest.AddWord("ikutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg", 1);
        forest.AddWord("ifffffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff", 1);
        forest.AddWord("iwqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", 1);
        forest.AddWord("oappkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkle", 1);
        forest.AddWord("oapplepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie", 1);
        forest.AddWord("oaptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen", 3);
        forest.AddWord("oalujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka", 2);
        forest.AddWord("oaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo", 1);
        forest.AddWord("oaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf", 1);
        forest.AddWord("oyrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr", 1);
        forest.AddWord("okutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg", 1);
        forest.AddWord("offfffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff", 1);
        forest.AddWord("owqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", 1);
        forest.AddWord("oiappkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkle", 1);
        forest.AddWord("oiapplepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie", 1);
        forest.AddWord("oiaptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen", 3);
        forest.AddWord("oialujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka", 2);
        forest.AddWord("oiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo", 1);
        forest.AddWord("oiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf", 1);
        forest.AddWord("oiyrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr", 1);
        forest.AddWord("oikutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg", 1);
        forest.AddWord("oifffffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff", 1);
        forest.AddWord("oiwqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", 1);

        forest.GetHitcount("applepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie");
        forest.GetHitcount("aptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen");
        forest.GetHitcount("alujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka");
        forest.GetHitcount("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo");
        forest.GetHitcount("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf");
        forest.GetHitcount("yrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr");
        forest.GetHitcount("kutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
        forest.GetHitcount("fffffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff");
        forest.GetHitcount("wqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        forest.GetHitcount("iappkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkle");
        forest.GetHitcount("iapplepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie");
        forest.GetHitcount("iaptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen");
        forest.GetHitcount("ialujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka");
        forest.GetHitcount("iaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo");
        forest.GetHitcount("iaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf");
        forest.GetHitcount("iyrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr");
        forest.GetHitcount("ikutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
        forest.GetHitcount("ifffffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff");
        forest.GetHitcount("iwqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        forest.GetHitcount("oappkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkle");
        forest.GetHitcount("oapplepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie");
        forest.GetHitcount("oaptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen");
        forest.GetHitcount("oalujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka");
        forest.GetHitcount("oaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo");
        forest.GetHitcount("oaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf");
        forest.GetHitcount("oyrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr");
        forest.GetHitcount("okutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
        forest.GetHitcount("offfffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff");
        forest.GetHitcount("owqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        forest.GetHitcount("oiappkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkle");
        forest.GetHitcount("oiapplepoooooooooooooooooooooooooooooooooooooooooooooooooooooojoooooooooooooooooooooooooooooooooooooie");
        forest.GetHitcount("oiaptyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyojyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyplepen");
        forest.GetHitcount("oialujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjojjjjjjjjjjjjjjjjjjjjjjjjjjjjttttttttpka");
        forest.GetHitcount("oiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaadildo");
        forest.GetHitcount("oiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaffsaf");
        forest.GetHitcount("oiyrhssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssshr");
        forest.GetHitcount("oikutyktffhfhhhhhhhfgffshgjttrhdhfdjjyjggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
        forest.GetHitcount("oifffffffffffffffffffffffffffffffffffffffffffffffffffdrrtrrrrrrrrrrrrrrrrrrrrrrrrfffffffffffffffffffff");
        forest.GetHitcount("oiwqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");
        forest.GetHitcount("oiwqffwwqrqwqeteqteqrqedqwrqwrqwruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuup");
    }
}
 */

void ParseInput() {
    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river",
            "bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand bangkok is the capital of thailand",
            "we are ready to go",
            "come on everybody shake you hands",
            "i love this game",
            "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
            "daddy daddy daddy dad dad dad",
            "tell me the meaning of being lonely",
            "just keep track of it",
            "how hard could it be",
            "it is going to be legen wait for it dary legendary",
            "we dont need no education",
            "london is the capital of great britain",
            "paris is the capital of france",
            "berlin is the capital of germany",
            "rome is the capital of italy",
            "madrid is the capital of spain",
            "lisboa is the capital of portugal",
            "bern is the capital of switzerland",
            "moscow is the capital of russia",
            "kiev is the capital of ukraine",
            "minsk is the capital of belarus",
            "astana is the capital of kazakhstan",
            "beijing is the capital of china",
            "tokyo is the capital of japan",
            "bangkok is the capital of thailand",
            "welcome to moscow the capital of russia the third rome",
            "amsterdam is the capital of netherlands",
            "helsinki is the capital of finland",
            "oslo is the capital of norway",
            "stockgolm is the capital of sweden",
            "riga is the capital of latvia",
            "tallin is the capital of estonia",
            "warsaw is the capital of poland",
            "the river goes through the entire city there is a house near it",
            "the wall",
            "walle",
            "is is is is",
            "milk a",
            "milk b",
            "milk c",
            "milk d",
            "milk e",
            "milk f",
            "milk g",
            "water a",
            "water b",
            "fire and earth",
            "london is the capital of great britain",
            "i am travelling down the river"
    };
    istringstream docs_input(Join('\n', docs));

    queue<char> word;
    size_t current_doc = 0;
    for (char c; c = docs_input.get();) {
        if (c == -1) {
            //cout << word << " " << current_doc << endl;
            while(!word.empty()) {
                word.pop();
            }
            break;
        }
        if (c != ' ' && c != '\n'){
            word.push(c);
        }
        else if (c == ' '){
            //cout << word << " " << current_doc << endl;
            while(!word.empty()) {
                word.pop();
            }
        }
        else if (c == '\n') {
            //cout << word << " " << current_doc << endl;
            while(!word.empty()) {
                word.pop();
            }
            current_doc++;
        }

    }
}

void TestGeneration() {
    LOG_DURATION("test generation");
    GenerateDocs();
}



void TestIterators() {
    string str = "hello";
    istringstream ss(str);
    istream_iterator<char> it(ss);
    WordIt word(it, 5);


    const vector<string> docs = {
            "we are ready to go",
            "come on everybody shake you hands"};
    istringstream docs_input(Join('\n', docs));

    Index index;
    index.Update(docs_input);
    index.Print();
}

void FileRead() {
    /*{
        LOG_DURATION("reading file");
        SearchServer srv;
        ifstream fin;
        fin.open("docs.txt");
        int count = 0;
        for (string str; getline(fin, str);) {
            count++;
            if (count % 1000 == 0) {
                cout << count << endl;
            }
        }
        fin.close();
    }*/
    /*{
        LOG_DURATION("From file");
        SearchServer srv;
        ifstream fin;
        fin.open("docs.txt");
        srv.UpdateDocumentBase(fin);
        fin.close();
    }*/

    /*double result = 0.0;
    int p = 100;
    while (p != 0){
        result += pow(26, p);
        p--;
    }
    cout << result << endl;*/


    vector<string> words_ = GenerateWords();
    //istringstream ss("");
    {
        LOG_DURATION("make data");
        //vector<string> words = GenerateWords();

        //istringstream ss = MakeStream(GenerateDocs(words_));

        //int count = 0;
        /*for (string current_document; getline(ss, current_document);) {
            count++;
            if (count % 1000 == 0) {
                cout << "*** " << count << endl;
            }
        }*/

    }

    /*{
        LOG_DURATION("parse kernel queue");  //14s
        queue<char> word;
        size_t current_doc = 0;
        for (char c; c = ss.get();) {
            if (c == -1) {
                while (!word.empty()) {
                    word.front();
                    word.pop();
                }
                break;
            }
            if (c != ' ' && c != '\n') {
                word.push(c);
            } else if (c == ' ') {
                while (!word.empty()) {
                    word.front();
                    word.pop();
                }
            } else if (c == '\n') {
                while (!word.empty()) {
                    word.front();
                    word.pop();
                }
                current_doc++;
            }
        }
    }*/
    /*vector<string_view> svs;
    {
        string ap = "   apple    pen   ";
        string_view app = ap;
        while (true) {
            size_t space = app.find(' ');
            svs.push_back(app.substr(0, space));
            if (space == app.npos){
                break;
            }
            else {
                app.remove_prefix(space + 1);
            }
        }
        cout << svs << endl;
    }*/

    /*{
        LOG_DURATION("sum vector");
        for (int i = 0; i < 5000000; i++) {
            vector<size_t> nums(50000, 1);
            for (const auto n : nums) {
                n == 7;
            }
        }

    }*/


    /*struct IndexHelper{
        IndexHelper(){
            v.reserve(100);
        }
        vector<uint16_t > v;
    };*/

    vector<string> words = GenerateWords();
    //cout << words[0] << endl;
    {
        LOG_DURATION("parse kernel string iterators"); //1.4s
        unordered_map<string, pair<vector<uint16_t>, unordered_map<uint16_t, uint16_t>>> index;
        //cout << index.size() << endl;
        //cout << index["fff"].v.size() << endl;
        //map<vector<uint64_t >, map<size_t, size_t>> hash_index;
        //Forest forest;
        uint16_t current_doc = 0;
        //vector<string> words = GenerateWords();
        TotalDuration make_ss("make_ss total");

        /*forest.AddWord("apple", 0);
        forest.AddWord("app", 1);
        forest.AddWord("apport", 2);
        forest.Print();*/


        /*string word1 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        string word2 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab";
        auto hashw1 = HashWord(word1);
        auto hashw2 = HashWord(word2);
        {
            LOG_DURATION("test str");
            for (int i = 0; i < 700000000; i++) {
                word1 < word2;
            }
        }
        {
            LOG_DURATION("test hash");
            for (int i = 0; i < 1000000; i++) {
                hashw1 < hashw2;
            }
        }
        auto hv = HashWord("mdrzaescduvhkfkdmfaeirlizwebwumsgkvqmoepnxgedvbkkybmozwlvgudtpkxnbjamgumqajtiprkkoeqqfoqkcreeafumvcx");
        cout << hv << endl;*/

        for (int i = 0; i < 50; i++) {
            istringstream ss("");
            {
                ADD_DURATION(make_ss);
                ss = MakeStream(GenerateDocs(words));
            }

            /*char c = 'a';
            while (c != -1) {
                c = ss.get();
            }*/

            for (string current_document; getline(ss, current_document);) {

                /*string word;
                word.reserve(100);
                for (const char c : current_document) {
                    if (c == ' '){
                        if (!word.empty()) {
                            index[move(word)];
                            word = "";
                            word.reserve(100);
                        }
                    }
                    else {
                        word.push_back(c);
                    }
                }*/

                char sep = ' ';
                std::string::size_type b = 0;
                while ((b = current_document.find_first_not_of(sep, b)) != std::string::npos) {
                    auto e = current_document.find_first_of(sep, b);

                    //hash<string> hash_fn;
                    //size_t hash1 = hash_fn(current_document.substr(b, e-b));
                    //current_document.substr(b, e-b);

                    //hash_index[HashWord(current_document.substr(b, e-b))][current_doc]++;

                    //cout << current_document.substr(b, e-b).size() << endl;
                    index[current_document.substr(b, e-b)].first.push_back(current_doc);
                    //forest.AddWord(current_document.substr(b, e-b), current_doc);
                    b = e;
                }
                //cout << current_doc << endl;
                current_doc++;

            }
            //cout << current_doc << endl;
            cout << i << endl;
            //cout << index << endl;

        }
        {
            LOG_DURATION("making maps");
            for (auto&[key, value] : index) {
                for (const auto n : value.first) {
                    value.second[n]++;
                }
            }
        }

        /*for (const auto& [key, value] : index) {
            cout << key << ": ";
            for (const auto& [num, count] : value.second) {
                cout << "{ " << num << ": " << count << "}, ";
            }
            cout << endl;
        }*/
        {
            LOG_DURATION("queries");
            for (int t = 0; t < 500000; t++) {
                if (t % 50000 == 0){
                    cout << t << endl;
                }
                vector<pair<uint16_t, uint16_t>> relev(50000);
                relev += index[words[0]].second;
                relev += index[words[1000]].second;
                relev += index[words[2000]].second;
                relev += index[words[3000]].second;
                relev += index[words[4000]].second;
                relev += index[words[5000]].second;
                relev += index[words[6000]].second;
                relev += index[words[7000]].second;
                relev += index[words[8000]].second;
                relev += index[words[9000]].second;
            }
        }

    }





}

int main() {
    //FileRead();

    //TestIterators();

    //TestGeneration();


    TestRunner tr;
    RUN_TEST(tr, TestSerpFormat);
    RUN_TEST(tr, TestTop5);
    RUN_TEST(tr, TestHitcount);
    RUN_TEST(tr, TestRanking);
    RUN_TEST(tr, TestBasicSearch);


    /*Forest forest;
    forest.AddWord("apple", 1);
    forest.AddWord("applepie", 1);
    forest.AddWord("applepen", 3);
    forest.AddWord("alupka", 2);
    forest.AddWord("apple", 1);
    forest.AddWord("hello", 6);
    forest.AddWord("hell", 6);
    forest.AddWord("hell", 7);
    //forest.Print();
    cout << forest.GetHitcount("apple") << endl;
    cout << forest.GetHitcount("applepie") << endl;
    cout << forest.GetHitcount("applepen") << endl;
    cout << forest.GetHitcount("alupka") << endl;
    cout << forest.GetHitcount("no") << endl;
    cout << forest.GetHitcount("hello") << endl;
    cout << forest.GetHitcount("hell") << endl;
    MeasureTreeTime();*/


    //TestSpeed();

    /*cout << endl << endl;
    {
        LOG_DURATION("new-new style");
        for (int i = 0; i < 1000; i++) {
            ParseInput();
        }
    }*/



    //TestReadingNew();

    /*{
        LOG_DURATION("Old-style");
        for (int i = 0; i < 1000; i++) {
            TestReadingOld();
        }
    }*/

    /*{
        LOG_DURATION("New-style");
        for (int i = 0; i < 1000; i++) {
            TestReadingNew();
        }
    }*/


    //TestReadingNew();
    //TestReadingOld();
}
