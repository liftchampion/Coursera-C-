#pragma once

#include <string>
#include <vector>
#include <random>
#include <sstream>
#include <ctime>
#include <fstream>
#include "test_runner.h"
#include "parse.h"

using namespace std;


vector<string> GenerateWords();
string GenerateDoc(const vector<string>& words);
vector<string> GenerateDocs(const vector<string>& words = GenerateWords());
istringstream MakeStream(const vector<string>& items);
