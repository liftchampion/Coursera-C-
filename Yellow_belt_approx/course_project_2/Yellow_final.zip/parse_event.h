#pragma once

#include <string>

using namespace std;

string ParseEvent(istream& is);
